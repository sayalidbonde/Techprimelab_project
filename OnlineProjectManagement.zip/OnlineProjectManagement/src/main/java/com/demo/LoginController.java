package com.demo;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.entity.Login;
import com.demo.service.UserService;

@Controller
public class LoginController {
 
 
   @Autowired
   private UserService service;
    
    @GetMapping("/login")
	public String userLogin()
	{
		return "login";
	}
 
    @PostMapping("/createUser")
    public String showWelcomePage(ModelMap model, @ModelAttribute Login login){
    	 
    	System.out.println(login);
		
		boolean flag = service.checkEmail(login.getEmail()); 
		
		if(flag)
		{
			model.put("errorMessage", "Invalid Credentials");
		}
		else
		{
			Login u_details = service.createUser(login);

			if(u_details != null)
			{
				return "redirect:/create_project";		
			}
			else
			{
				model.put("errorMessage", "Invalid Credentials");
			}
		}
		return "redirect:/create_project";	
    }
    
    @GetMapping("/dashboard")
   	public String createDashboard()
   	{
   		return null;
   	}
    
    @GetMapping("/create_project")
	public String createProject()
	{
		return null;
	}
}