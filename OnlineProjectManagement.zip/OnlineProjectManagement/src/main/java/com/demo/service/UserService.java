package com.demo.service;

import com.demo.entity.Login;

public interface UserService {

	public Login createUser(Login log);
	
	public boolean checkEmail(String email);
}
