package com.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.dao.UserRepository;
import com.demo.entity.Login;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository repo;

	@Override
	public Login createUser(Login log) {

		return repo.save(log);
	}

	@Override
	public boolean checkEmail(String email) {

		return repo.existsByEmail(email);
	}

}
